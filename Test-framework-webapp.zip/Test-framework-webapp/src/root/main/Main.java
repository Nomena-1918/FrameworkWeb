package root.main;

import database.ConnectionPerso;
import root.classesTest.EmpModel;
import root.classesTest.Plat;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.TimeZone;

import static java.time.LocalTime.now;

public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("\n\tTest-framework-webapp built successfully ! 🚀\n\n");

        Connection c = ConnectionPerso.getConnection();

        Plat plat = new Plat();
        List<Object> listPlat = plat.select(c);

        EmpModel emp = new EmpModel();
        List<Object> listEmp = emp.select(c);

        String query = "insert into empmodel_plat values(default, ?, ?, ?, ?)";
        PreparedStatement stmt = c.prepareStatement(query);

        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        isoFormat.setTimeZone(TimeZone.getTimeZone("America/Los_Angeles"));

        java.util.Date date = isoFormat.parse("2010-05-23T22:01:02");
        TimeZone.setDefault(TimeZone.getTimeZone("America/Los_Angeles"));
        java.sql.Date sqlDate = new java.sql.Date(date.getTime());

        stmt.setInt(1, 1);
        stmt.setInt(2, 1);
        stmt.setDate(3, sqlDate);
        stmt.setString(4, "truc");

        stmt.executeUpdate();
    }
}
